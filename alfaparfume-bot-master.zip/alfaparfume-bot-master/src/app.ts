import ShoppingCart from './services/ShoppingCart'
import papyrus from './stubs/papyrus'
import { validateAddress, onDocumentReceived } from './utils'
import { availableScenarious } from './helpers/markup'
import { inlineKeyboards } from './services/Keyboards/inlineKeyboards'
import { anthology } from './services/Scenario'
import { session } from './services/Session'
import { bot } from './bootstrap'

const shoppingCart = new ShoppingCart()

bot.start(async ctx => {
  try {
    return await anthology.get('initial')(ctx)
  } catch (err) {
    console.error(err)
  }
})

bot.on('inline_query', async ctx => {
  try {
    const inlineQuery = ctx.inlineQuery.query
    const [prefix, query] = inlineQuery.split(':')
    return await anthology.get('getProductsByCategory')(ctx)(query)
  } catch (err) {
    console.error(err)
  }
})

bot.on('pre_checkout_query', async ctx => {
  try {
    ctx.answerPreCheckoutQuery(true)
  } catch (err) {
    console.error(err)
  }
})

bot.on('successful_payment', async ctx => {
  try {
    await anthology.get('invoiceFinal')(ctx)
  } catch (err) {
    console.error(err)
  }
})

bot.on('document', async ctx => {
  try {
    const {
      from: { id: userId },
    } = ctx
    const scope = await session.getEntity(userId, 'scope')

    await onDocumentReceived(ctx, scope, userId)
  } catch (err) {
    console.error(err)
  }
})

bot.on('message', async ctx => {
  try {
    const {
      from: { id: userId },
      message,
    } = ctx
    const scope = await session.getEntity(userId, 'scope')
    const userMessage: string = ctx.message.text

    if (userMessage === '/createPromotion') {
      return await anthology.get('createPromotion')(ctx)
    }
    if (userMessage === '/uploadClients') {
      return await anthology.get('uploadClients')(ctx)
    }
    if (userMessage === '/deletePromotion') {
      return await anthology.get('deletePromotion')(ctx)
    }
    if (userMessage === papyrus.discardOrder) {
      return await anthology.get(availableScenarious.discardOrder)(ctx)
    }
    if (userMessage === papyrus.discardAction) {
      return await anthology.get(availableScenarious.discardAction)(ctx)
    }
    if (userMessage === papyrus.findByBarcode) {
      return await anthology.get(availableScenarious.findByBarcode)(ctx)
    }
    if (scope === 'findByBarcode') {
      return await anthology.get(availableScenarious.onFindByBarcode)(ctx)
    }
    if (scope === 'onEnterPromotionName') {
      return await anthology.get('promotionNameReceived')(ctx)(userMessage)
    }
    if (scope === 'clientPhone') {
      return await anthology.get('clientPhoneReceived')(ctx)(userMessage)
    }
    if (scope === 'inputReview') {
      return await anthology.get('publicReview')(ctx)(userMessage)
    }
    if (scope === 'enterAddress') {
      if (!validateAddress(userMessage)) {
        return await ctx.reply(papyrus.uncorrectAddress)
      }
      await session.update(userId, 'scope', '')
      await session.update(userId, 'address', userMessage)
      return await anthology.get('paymentMethodSelect')(ctx)
    }
    if (scope === 'askPhoneNumber') {
      return await anthology.get('userPhoneNumber')(ctx)
    }
    if (scope === 'enterQty') {
      return await anthology.get('qtyEntered')(ctx)(userMessage)
    }
    if (userMessage !== undefined && userMessage.match(/Продукт:[\w\W]*/)) {
      return await anthology.get('selectedProduct')(ctx)(userMessage)
    }
    if (Object.values(availableScenarious).indexOf(userMessage) > -1) {
      for (const prop in availableScenarious) {
        if (availableScenarious.hasOwnProperty(prop)) {
          if (availableScenarious[prop] === userMessage) {
            return await anthology.get(prop)(ctx)
          }
        }
      }
    }
  } catch (err) {
    console.error(err)
  }
})

bot.on('callback_query', async ctx => {
  try {
    const {
      from: { id: userId },
    } = ctx
    const callbackData = ctx.callbackQuery.data
    if (callbackData.match(/selectedPromotionType:[\w|\W]*/)) {
      return await anthology.get('selectedPromotionType')(ctx)(callbackData)
    }
    if (callbackData === 'cart') {
      return await anthology.get('cart')(ctx)
    }
    if (callbackData.match(/(displayPage:)[\w|\d|\s|:|(а-яА-Я)]*/)) {
      return await anthology.get('displayPage')(ctx)(callbackData)
    }
    if (callbackData.match(/(typeAddress:)[\w|\d|\s|:|(а-яА-Я)]*/)) {
      return await anthology.get('typeAddress')(ctx)(callbackData)
    }
    if (callbackData.match(/(orderSummary:)[\w|\d|\s|:|(а-яА-Я)]*/)) {
      return await anthology.get('orderSummary')(ctx)(callbackData)
    }
    if (callbackData.match(/(editProductQty:)[\w|\d|\s|:|(а-яА-Я)]*/)) {
      return await anthology.get('editProductQty')(ctx)(callbackData)
    }
    if (callbackData.match(/(operateQty:)[\w|\d|\s|:|(а-яА-Я)]*/)) {
      return await anthology.get('operateQty')(ctx)(callbackData)
    }
    if (callbackData.match(/(acceptQty:)[\w|\d|\s|:|(а-яА-Я)]*/)) {
      return await anthology.get('acceptQty')(ctx)(callbackData)
    }
    if (callbackData.match(/(selectedPromotionForDelete:)[\w|\d|\s|:|(а-яА-Я)]*/)) {
      return await anthology.get('selectedPromotionForDelete')(ctx)(callbackData)
    }
    if (callbackData.match(/delete:\w*/)) {
      const productId = callbackData.replace('delete:', '')
      await shoppingCart.removeProduct([productId], userId)
      return await ctx.editMessageReplyMarkup({
        inline_keyboard: inlineKeyboards.inlineCart(await session.getEntity(userId, 'cart')),
      })
    }
    if (Object.values(availableScenarious).indexOf(callbackData) > -1) {
      for (const prop in availableScenarious) {
        if (availableScenarious.hasOwnProperty(prop)) {
          if (availableScenarious[prop] === callbackData) {
            return await anthology.get(prop)(ctx)
          }
        }
      }
    }
  } catch (err) {
    console.error(err)
  }
})
