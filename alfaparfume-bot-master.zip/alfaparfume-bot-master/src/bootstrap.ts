import dotenv from 'dotenv'
import Telegraf from 'telegraf'

dotenv.config()

const bot = new Telegraf(process.env.BOT_TOKEN)

try {
  bot.launch()
  console.info('Bot started on Long-Polling server.')
} catch (err) {
  console.error('Error at starting bot: ', err)
}

export { bot }