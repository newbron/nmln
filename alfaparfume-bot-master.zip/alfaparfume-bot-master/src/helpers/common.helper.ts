import { Extra } from 'telegraf'

export const clearInlineKeyboard = async ctx => {
  const {
    from: { id: userId },
  } = ctx
  await ctx.telegram.editMessageReplyMarkup(userId, { inline_keyboard: [] })
}

export const clearKeyboard = async (ctx: any, message: string) => {
  return await ctx.reply(
    message,
    Extra.markup(markup => markup.removeKeyboard()),
  )
}

export const clearInlineQuery = async (ctx: any) => {

}
