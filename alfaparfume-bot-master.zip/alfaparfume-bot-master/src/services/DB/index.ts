import dotenv from 'dotenv'
import mongoose from 'mongoose'

import { PromotionsSchema } from './models/promotions'
import { ProductsSchema } from './models/products'
import { ClientSchema } from './models/contragents'
import { ReviewsSchema } from './models/reviews'

import { IPromotion, IProduct } from '../../shared'

dotenv.config()

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
const ProductsModel = mongoose.model<IProduct>('Products', ProductsSchema, 'products')
const ClientModel = mongoose.model('Clients', ClientSchema, 'contragents')
const ReviewsModel = mongoose.model('Reviews', ReviewsSchema, 'reviews')
const PromotionsModel = mongoose.model<IPromotion>('Promotions', PromotionsSchema, 'promotions')

export { ProductsModel, ClientModel, ReviewsModel, PromotionsModel }
