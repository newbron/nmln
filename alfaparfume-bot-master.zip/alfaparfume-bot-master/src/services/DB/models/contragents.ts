import { Schema } from 'mongoose'

export interface IClient {
  managerName: string, phoneNumber: string, mainManager: string
}

export const ClientSchema: Schema = new Schema({
  managerName: String,
  phoneNumber: String,
  mainManager: String
})
