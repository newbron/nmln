import { Schema } from 'mongoose'

export const ProductsSchema: Schema = new Schema({
  articule: String,
  title: String,
  startSale: String,
  description: String,
  endSale: String,
  priceBefore: Number,
  priceAfter: Number,
  photoUrl: String,
  linkedPromotion: String
})
