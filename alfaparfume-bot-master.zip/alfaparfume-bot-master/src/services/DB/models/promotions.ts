import { Schema } from 'mongoose'

const PromotionsSchema: Schema = new Schema({
  nomination: String,
  type: String
})

export { PromotionsSchema }