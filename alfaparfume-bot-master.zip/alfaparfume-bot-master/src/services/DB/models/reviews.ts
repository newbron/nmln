import { Schema } from 'mongoose'

const ReviewsSchema: Schema = new Schema({
	ownerName: String,
	reviewContent: String
})

export { ReviewsSchema }