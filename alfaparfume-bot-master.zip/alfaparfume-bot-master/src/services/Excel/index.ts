import excelToJson from 'convert-excel-to-json'
import { ProductsModel, ClientModel } from '../DB'

export const uploadGoods = async (filePath: string, promoId: string) => {
  const result = await excelToJson({
    sourceFile: filePath
  })
  const parsedData = await result.TDSheet
  await parsedData.shift()

  return await parsedData.forEach(async good => {
    await ProductsModel.create({
      articule: good.A,
      title: good.B,
      description: good.C,
      startSale: good.D,
      endSale: good.E,
      priceBefore: good.F,
      priceAfter: good.G,
      photoUrl: good.I,
      linkedPromotion: promoId
    })
  })
}

export const returnContragentsFromExcel = async (filePath: string) => {
  const result = await excelToJson({
    sourceFile: filePath
  })
  const parsedData = result.TDSheet
  await parsedData.shift()
  await ClientModel.deleteMany({})
  return await parsedData.forEach(async contragent => {
    await ClientModel.create({
      managerName: contragent.A,
      phoneNumber: contragent.B,
      mainManager: contragent.C
    })
  })
}
