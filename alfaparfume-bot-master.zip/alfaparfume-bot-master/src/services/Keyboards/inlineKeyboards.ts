import { IPromotion, discountTypes, ICartProduct } from '../../shared'

export const inlineKeyboards = {
  inlineCart(cart: ICartProduct[]) {
    if (cart.length === 0) {
      return [[{ text: '🤷‍♂️Кошик порожній', callback_data: 'empty' }]]
    }
    const keyboardsArray = []
    cart.map(product => {
      const actions = [
        {
          text: `${product.qty}шт/${Math.round(Number(product.qty) * product.priceBefore)}грн`,
          callback_data: `editProductQty:${product.articule}`,
        },
        {
          text: '🚫 Видалити',
          callback_data: `delete:${product.articule}`,
        },
      ]
      const title = [
        {
          text: `📦 ${product.title}`,
          callback_data: 'empty',
        },
      ]
      keyboardsArray.unshift(title, actions)
    })
    keyboardsArray.push([{ text: '💸 Оформити замовлення', callback_data: 'formOrder' }])
    return keyboardsArray
  },
  summaryKeyboard(name, phone, paymentMethod, address, summaryPrice) {
    return [
      [
        { text: "🧑Ім'я:", callback_data: 'empty' },
        { text: name, callback_data: 'empty' },
      ],
      [
        { text: '📞Номер телефону:', callback_data: 'empty' },
        { text: phone, callback_data: 'empty' },
      ],
      [
        { text: '💰Спосіб оплати', callback_data: 'empty' },
        { text: paymentMethod, callback_data: 'empty' },
      ],
      [
        { text: '🗺Адреса', callback_data: 'empty' },
        { text: address, callback_data: 'empty' },
      ],
      [
        { text: '🏷️Підсумкова ціна:', callback_data: 'empty' },
        { text: Math.round(summaryPrice), callback_data: 'empty' },
      ],
      [
        { text: '🚫 Відхилити', callback_data: 'discardOrder' },
        { text: '✅ Підтвердити', callback_data: 'acceptOrder' },
      ],
    ]
  },
  paymentMethods: [
    [{ text: '💰Готівкова оплата', callback_data: 'orderSummary:Готівковий' }],
    [{ text: '💳Безготівкова оплата', callback_data: 'orderSummary:Безготівковий' }],
  ],
  getPromotionTypes: () => {
    const keyboard = []
    discountTypes.forEach(type => {
      keyboard.push([
        {
          text: type,
          callback_data: `selectedPromotionType:${type}`,
        },
      ])
    })
    return keyboard
  },
  rebateKeyboard: (promotions: IPromotion[]) => {
    const keyboard = []
    promotions.forEach(promotion => {
      keyboard.push([
        {
          text: `${promotion.nomination}`,
          switch_inline_query_current_chat: `getProductsByCategory:${promotion._id}`,
        },
      ])
    })
    return keyboard
  },
  selectDeliveryMethod: [
    [
      { text: '🔴Нова Пошта', callback_data: 'typeAddress:NovaPoshta' },
      { text: '🔵Justin', callback_data: 'typeAddress:Justin' },
      { text: "🚛Кур'єром", callback_data: 'typeAddress:APCourier' },
    ],
  ],
  productAddedKeyboard: promotions => {
    const keyboard = []
    promotions.forEach(promotion => {
      keyboard.push([
        {
          text: `${promotion.nomination}`,
          switch_inline_query_current_chat: `getProductsByCategory:${promotion._id}`,
        },
      ])
    })
    keyboard.push([{ text: '🛒Кошик', callback_data: 'cart' }])
    return keyboard
  },
  productEditKeyboard: productObject => [
    [
      {
        text: '-',
        callback_data: `operateQty:${productObject.articule}:${Number(productObject.qty) - 1}`,
      },
      { text: `⚖ ${productObject.qty}шт`, callback_data: 'empty' },
      {
        text: '+',
        callback_data: `operateQty:${productObject.articule}:${Number(productObject.qty) + 1}`,
      },
    ],
    [
      {
        text: '✅Застосувати',
        callback_data: `acceptQty:${productObject.articule}:${productObject.qty}`,
      },
    ],
  ],
  removePromotions: promotions => {
    const keyboard = []
    promotions.forEach(promotion => {
      keyboard.push([
        { text: promotion.nomination, callback_data: 'empty' },
        { text: '❌', callback_data: `selectedPromotionForDelete:${promotion._id}` },
      ])
    })
    return keyboard
  },
}
