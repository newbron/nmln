import { availableScenarious } from '../../helpers/markup'
import papyrus from '../../stubs/papyrus'

export default {
  initial: [
    [availableScenarious.promotions, availableScenarious.info],
    [availableScenarious.reviews, availableScenarious.cart],
  ],
  info: [
    [availableScenarious.infoPayment, availableScenarious.infoDelivery],
    [availableScenarious.infoContacts, availableScenarious.infoBack],
  ],
  review: [
    [availableScenarious.addReview, availableScenarious.viewReviews],
    [availableScenarious.infoBack],
  ],
  discardFindByBarcore: [[papyrus.discardAction]],
  discardOrder: [[papyrus.discardOrder]],
}
