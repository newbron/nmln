import winston from 'winston'
import TelegramLogger from 'winston-telegram'
import Telegraf from 'telegraf'
import moment from 'moment'
import dotenv from 'dotenv'

dotenv.config()

const loggerBot = new Telegraf(process.env.INFO_BOT_TOKEN)
const { combine, label, printf, colorize, timestamp } = winston.format
const logLabel = 'AP'
const clientLabel = '[🍶 AlfaParfum]'
const logTimestamp = moment().format('MM-DD-YY H:mm:ss')
const logMessageFormat = printf(info => `[${info.label}]: ${info.message} | ${info.timestamp}`)
const levels = {
  ...winston.config.syslog.levels,
  telegram_technical: 8,
  telegram_info: 9,
  telegram_client: 10,
}
winston.addColors({
  debug: 'white',
  error: 'red',
  info: 'cyan',
  silly: 'white',
  verbose: 'blue',
  warn: 'yellow',
})

const winstonLogger = winston.createLogger({
  levels,
  transports: [
    new winston.transports.Console({
      level: 'info',
      format: combine(
        label({ label: logLabel }),
        colorize({ all: true, colors: { info: 'blue', error: 'red' } }),
        timestamp({ format: logTimestamp }),
        logMessageFormat,
      ),
    }),
    new TelegramLogger({
      level: 'telegram_technical',
      template: `[${logLabel}]: {message} | ${logTimestamp}`,
      token: process.env.INFO_BOT_TOKEN,
      chatId: Number(process.env.CHAT_ID_AP),
      unique: true,
    }),
    new TelegramLogger({
      level: 'telegram_client',
      template: `[${clientLabel}]: {message}`,
      token: process.env.INFO_BOT_TOKEN,
      chatId: Number(process.env.CHAT_ID_AP),
      unique: true,
    }),
  ],
})

export const logger = async (level, msg: any) => {
  if (process.env.NODE_ENV === 'development') {
    return console.info(msg)
  }
  if (level === 'client') {
    return await winstonLogger.log('telegram_client', `\n${msg}`)
  }
  if (level === 'technical') {
    return await winstonLogger.log('telegram_technical', msg)
  }
}
