import dotenv from 'dotenv'

dotenv.config()

const productInvoiceBB = (orderId: string | number, price: number | string) => {
  return {
    provider_token: process.env.PROVIDER_TOKEN,
    start_parameter: `order-${orderId}`,
    title: `Замовлення ${orderId}`,
    description: `Замовлення ${orderId}`,
    currency: 'uah',
    prices: [{ label: 'Стандартный Пакет', amount: `${price}00` }],
    payload: {
      coupon: 'Alfaparfume_Coupon',
    },
  }
}

export { productInvoiceBB }
