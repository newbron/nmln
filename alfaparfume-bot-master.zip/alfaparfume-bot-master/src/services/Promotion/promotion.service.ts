import { ICartProduct } from '../../shared'
import papyrus from '../../stubs/papyrus'

export class PromotionService {
  public static defineAmount(promotionType: string, amount: number): number {
    let bonusAmount = 0
    switch (promotionType) {
      case '5+5':
        bonusAmount = Math.round(amount / 10)
        return amount + bonusAmount
        break
      case '3+2':
        bonusAmount = Math.round(amount / 5) * 2
        return amount + bonusAmount
        break
      case 'alta moda':
        return amount
        break
      default:
        return 0
        break
    }
  }

  public static defineItemDiscountPrice(promotionType: string, product: ICartProduct): number {
    let itemDiscountPrice = 0
    const itemPrice = Math.round(product.qty * product.priceBefore)
    switch (promotionType) {
      case '5+5':
        if (product.qty < 10 && product.qty % 10 !== 0) {
          itemDiscountPrice = itemPrice
        } else {
          itemDiscountPrice = Math.round(itemPrice * 0.5)
        }
        break
      case '3+2':
        if (product.qty < 5 && product.qty % 5 !== 0) {
          itemDiscountPrice = itemPrice
        } else {
          itemDiscountPrice = Math.round(itemPrice - itemPrice * 0.4)
        }
        break
      case 'alta moda':
        itemDiscountPrice = Math.round(itemPrice * 0.5)
        break
    }
    return itemDiscountPrice
  }

  public static defineLimitationNotification(promotionType: string, amount: number): string {
    let limitationNotification = ''
    switch (promotionType) {
      case '5+5':
        if (amount < 10 || amount % 10 !== 0) {
          limitationNotification += papyrus.fivePromoWarning
          break
        }
        limitationNotification += papyrus.productAdded
        break
      case '3+2':
        if (amount < 5 || amount % 5 !== 0) {
          limitationNotification += papyrus.threePromoWarning
          break
        }
        limitationNotification += papyrus.productAdded
        break
      default:
        limitationNotification += papyrus.productAdded
    }
    return limitationNotification
  }

  public static compareDiscountPrices(cart: ICartProduct[]): string {
    let normalPrice = 0
    let discountPrice = 0
    cart.forEach(product => {
      const [normalPriceChunk, discountPriceChunk] = this.defineChunkPrices(product)
      normalPrice += normalPriceChunk
      discountPrice += discountPriceChunk
    })
    return papyrus.promotionPriceComparison(Math.round(normalPrice), Math.round(discountPrice))
  }

  public static defineChunkPrices(product: ICartProduct): number[] {
    const normalChunkPrice = product.qty * product.priceBefore
    const discountChunkPrice = this.defineItemDiscountPrice(product.discountType, product)

    return [normalChunkPrice, discountChunkPrice]
  }
}
