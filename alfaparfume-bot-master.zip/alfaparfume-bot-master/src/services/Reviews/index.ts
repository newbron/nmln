import { ReviewsModel } from '../DB'

const addUserToReviews = async (userName: string, userReview: string) => {
  return await ReviewsModel.create({
    ownerName: userName,
    reviewContent: userReview
  })
}

export { addUserToReviews }