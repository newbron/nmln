import Markup from 'telegraf/markup'
import Extra from 'telegraf/extra'
import axios from 'axios'

import papyrus from '../../stubs/papyrus'
import keyboards from '../Keyboards/keyboard'
import { EDeliveryTypes, ICartProduct } from '../../shared'
import ShoppingCart from '../ShoppingCart'
import { PromotionService } from '../Promotion'
import { logger } from '../Logger'
import { ProductsModel, ClientModel, ReviewsModel, PromotionsModel } from '../DB'
import { addUserToReviews } from '../Reviews'
import { inlineKeyboards } from '../Keyboards/inlineKeyboards'
import {
  validatePhone,
  paginator,
  apChatSummaryMessage,
  userSummaryMessage,
  getResultDiscount,
  validatePromotionName,
  getFileUrl,
} from '../../utils'
import { session } from '../Session'
import { availableScenarious, clearInlineKeyboard } from '../../helpers'

const shoppingCart = new ShoppingCart()

const scenarious = {
  initial: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.init(userId)
    await session.update(userId, 'scope', 'clientPhone')
    await ctx.reply(
      papyrus.requestClientPhone,
      Extra.markup(markup => markup.removeKeyboard()),
    )
  },
  promotions: async ctx => {
    const promotions = await PromotionsModel.find({})
    return await ctx.reply(
      papyrus.promotions,
      Markup.inlineKeyboard(inlineKeyboards.rebateKeyboard(promotions))
        .resize()
        .extra(),
    )
  },
  info: async ctx => {
    return await ctx.reply(
      papyrus.info,
      Markup.keyboard(keyboards.info)
        .resize()
        .extra(),
    )
  },
  infoPayment: async ctx => {
    return await ctx.reply(papyrus.infoPayment)
  },
  infoDelivery: async ctx => {
    return await ctx.reply(papyrus.infoDelivery)
  },
  infoContacts: async ctx => {
    return await ctx.reply(papyrus.infoContacts)
  },
  infoBack: async ctx => {
    return await ctx.reply(
      papyrus.infoBack,
      Markup.keyboard(keyboards.initial)
        .resize()
        .extra(),
    )
  },
  reviews: async ctx => {
    return await ctx.reply(
      papyrus.reviews,
      Markup.keyboard(keyboards.review)
        .resize()
        .extra(),
    )
  },
  addReview: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.update(userId, 'scope', 'inputReview')
    return await ctx.reply(
      papyrus.inputReview,
      Extra.markup(markup => markup.removeKeyboard()),
    )
  },
  discardAction: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.update(userId, 'scope', '')
    return await ctx.reply(
      papyrus.refused,
      Markup.keyboard(keyboards.initial)
        .resize()
        .extra(),
    )
  },
  findByBarcode: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.update(userId, 'scope', 'findByBarcode')
    return await ctx.reply(
      papyrus.onFindByBarcode,
      Markup.keyboard(keyboards.discardFindByBarcore)
        .resize()
        .extra(),
    )
  },
  onFindByBarcode: async ctx => {
    const {
      message: { photo },
    } = ctx
    if (!photo) {
      return await ctx.reply(papyrus.uploadBarcodePhoto)
    }
    const fileId = photo[0].file_id
    if (!fileId) {
      return await ctx.reply(papyrus.errorOnBarcodUpload)
    }
    const fileUrl = await getFileUrl(fileId)
    if (!fileUrl) {
      return await ctx.reply(papyrus.errors.fileBarcodeWrong)
    }
    console.log('file url data', fileUrl)

    // await session.update(userId, 'scope', 'findByBarcode')
    // return await ctx.reply(
    //   papyrus.onFindByBarcode,
    //   Markup.keyboard(keyboards.discardFindByBarcore)
    //     .resize()
    //     .extra(),
    // )
  },
  viewReviews: async ctx => {
    let reviewsList = papyrus.responsesList
    const reviewsArray: any = await ReviewsModel.find({})
    if (reviewsArray.length === 0) {
      return await ctx.reply(papyrus.noReviews)
    }
    reviewsArray.forEach(review => {
      reviewsList += `\n\n👤${review.ownerName}: 📢${review.reviewContent}`
    })
    return await ctx.reply(reviewsList)
  },
  publicReview: ctx => async (userReview: string) => {
    const {
      from: { id: userId },
    } = ctx
    if (userReview.length < 5) {
      return await ctx.reply(papyrus.uncorrectReview)
    }
    await addUserToReviews(ctx.from.first_name, userReview)
    await session.update(userId, 'scope', '')
    return await ctx.reply(
      papyrus.reviewAdded,
      Markup.keyboard(keyboards.review)
        .resize()
        .extra(),
    )
  },
  cart: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    const userCart = await session.getEntity(userId, 'cart')
    if (userCart.length === 0) {
      return await ctx.reply(papyrus.emptyCart)
    }

    return await ctx.reply(
      papyrus.cart,
      Markup.inlineKeyboard(inlineKeyboards.inlineCart(userCart))
        .resize()
        .extra(),
    )
  },
  selectedProduct: ctx => async (productData: string) => {
    const [preifx, articule, linkedPromotion] = productData.split(':')
    const promotionData = await PromotionsModel.findById(linkedPromotion)
    const currentProduct = await ProductsModel.findOne({ articule, linkedPromotion })
    const {
      from: { id: userId },
    } = ctx
    await session.update(
      userId,
      'chosenProduct',
      `${currentProduct._id}:${promotionData.nomination}`,
    )
    await session.update(userId, 'scope', 'enterQty')
    return await ctx.reply(papyrus.enterProductCount)
  },
  qtyEntered: ctx => async (amount: number) => {
    if (amount <= 0) {
      return await ctx.reply(papyrus.disallowedProductCount)
    }
    const {
      from: { id: userId },
    } = ctx
    const curProductData = await session.getEntity(userId, 'chosenProduct')
    const [productId, promoName] = curProductData.split(':')
    console.log(curProductData)
    const promotionData = await PromotionsModel.findOne({ nomination: promoName })
    console.log(promotionData)
    const discounts = await session.getEntity(userId, 'discounts')
    const promotions = await PromotionsModel.find({})
    const curProduct = await ProductsModel.findById(productId)
    const { title, priceBefore, priceAfter } = curProduct
    const productObject: ICartProduct = {
      title,
      priceBefore,
      priceAfter,
      qty: Number(amount),
      articule: curProduct.articule,
      discountType: promotionData.type,
      itemPrice: 0,
    }
    const itemPrice = PromotionService.defineItemDiscountPrice(promotionData.type, productObject)
    productObject.itemPrice = itemPrice
    await shoppingCart.addProduct(productObject, userId)
    await session.update(userId, 'scope', '')
    await session.update(userId, 'discounts', getResultDiscount(discounts, promoName))
    await session.update(userId, 'chosenProduct', '')
    return await ctx.reply(
      PromotionService.defineLimitationNotification(promotionData.type, amount),
      Markup.inlineKeyboard(inlineKeyboards.productAddedKeyboard(promotions))
        .resize()
        .extra(),
    )
  },
  formOrder: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.update(userId, 'scope', '')
    await anthology.get('addressSelect')(ctx)
    await ctx.editMessageReplyMarkup({ inline_keyboard: [] })
    return await ctx.reply(
      papyrus.correctPhoneNumber,
      Markup.keyboard(keyboards.discardOrder)
        .resize()
        .extra(),
    )
  },
  addressSelect: async ctx => {
    return await ctx.reply(
      papyrus.selectDeliveryMethod,
      Markup.inlineKeyboard(inlineKeyboards.selectDeliveryMethod)
        .resize()
        .extra(),
    )
  },
  typeAddress: ctx => async userAddressType => {
    const {
      from: { id: userId },
    } = ctx
    const [prefix, addressType] = userAddressType.split(':')
    if (addressType === EDeliveryTypes[0]) {
      await session.update(userId, 'addressType', 'Нова пошта')
      await ctx.reply(papyrus.typeAddress('Віділення Нової пошти'))
    }
    if (addressType === EDeliveryTypes[2]) {
      await session.update(userId, 'addressType', "Кур'єр")
      await ctx.reply(papyrus.courierDelivery)
    }
    if (addressType === EDeliveryTypes[1]) {
      await session.update(userId, 'addressType', 'Justin')
      await ctx.reply(papyrus.typeAddress('Віділення "Justin"'))
    }
    await session.update(userId, 'scope', 'enterAddress')
    return await ctx.editMessageReplyMarkup({ inline_keyboard: [] })
  },
  paymentMethodSelect: async ctx => {
    return await ctx.reply(
      papyrus.paymentMethod,
      Markup.inlineKeyboard(inlineKeyboards.paymentMethods)
        .resize()
        .extra(),
    )
  },
  displayPage: ctx => async rawPage => {
    const [prefix, page] = await rawPage.split(':')

    const contragents = await ClientModel.find({})
    const paginatedResult = paginator(contragents, 4)
    if (page < 0 || paginatedResult(page).length < 1) {
      return await ctx.reply(papyrus.noContragents)
    }
    const intermateInlineKeyboard = [
      [
        { text: '👈', callback_data: `displayPage:${Number(page) - 1}` },
        { text: '👉', callback_data: `displayPage:${Number(page) + 1}` },
      ],
    ]
    paginatedResult(page).forEach(async contragent => {
      intermateInlineKeyboard.unshift([
        { text: contragent.managerName, callback_data: `orderSummary:${contragent._id}` },
      ])
    })
    return await ctx.editMessageReplyMarkup({ inline_keyboard: intermateInlineKeyboard })
  },
  orderSummary: ctx => async (paymentMethodData: string) => {
    try {
      const {
        from: { first_name, id: userId },
      } = ctx
      await ctx.editMessageReplyMarkup({ inline_keyboard: [] })
      const [prefix, paymentMethod] = paymentMethodData.split(':')
      await session.update(userId, 'paymentMethod', paymentMethod)
      const phone = await session.getEntity(userId, 'phone')
      const address = await session.getEntity(userId, 'address')
      const cart = await session.getEntity(userId, 'cart')
      const summaryPrice = await shoppingCart.getTotalAmount(cart)
      await ctx.reply(
        papyrus.orderSummary,
        Markup.inlineKeyboard(
          inlineKeyboards.summaryKeyboard(first_name, phone, paymentMethod, address, summaryPrice),
        )
          .resize()
          .extra(),
      )
      return await ctx.reply(PromotionService.compareDiscountPrices(cart))
    } catch (err) {
      console.error(err)
    }
  },
  discardOrder: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.checkout(userId)
    await ctx.editMessageReplyMarkup({ inline_keyboard: [] })
    return await ctx.reply(
      papyrus.orderDiscarded,
      Markup.keyboard(keyboards.initial)
        .resize()
        .extra(),
    )
  },
  acceptOrder: async ctx => {
    try {
      const {
        from: { first_name, id: userId },
      } = ctx
      await ctx.editMessageReplyMarkup({ inline_keyboard: [] })
      const {
        phone,
        address,
        addressType,
        cart,
        paymentMethod,
        contragent,
        discounts,
      } = await session.receiveSession(userId)
      const apiProducts = []
      cart.forEach(product => {
        const { articule, title, qty, price, discountType } = product
        apiProducts.push({
          code: articule,
          name: title,
          quantity: qty,
          price: price,
          discountType: discountType,
        })
      })
      const apiResponse = await axios.get('http://rdc.parfume.ua:81/UT3/hs/PostOrder/PostData', {
        headers: {
          'Content-Type': 'application/json',
        },
        params: {
          param: `{"phone":"${phone}","address":"${addressType} ${address}","discount":"${discounts}","payemntMethod":"${paymentMethod}","contragent":"${contragent}","products":${JSON.stringify(
            apiProducts,
          )}`,
        },
        auth: {
          username: process.env.USER_1C,
          password: process.env.PASSWORD_1C,
        },
      })
      if (apiResponse.data && apiResponse.data.code === 206) {
        const unavailableIds = apiResponse.data.UnavailableProducts
        const unavailableProducts = await ProductsModel.find({
          articule: { $in: unavailableIds },
        }).lean()
        const messArticules = []
        unavailableProducts.forEach(product => messArticules.push(product.articule))
        await shoppingCart.removeProduct(messArticules, userId)
        return await ctx.reply(
          papyrus.uncorrectProductQty(unavailableProducts),
          Markup.keyboard(keyboards.initial)
            .resize()
            .extra(),
        )
      }
      await session.checkout(userId)
      const userSummaryPrice = await shoppingCart.getTotalAmount(cart)
      await logger(
        'client',
        apChatSummaryMessage(first_name, phone, address, cart, userSummaryPrice),
      )
      return await ctx.reply(
        userSummaryMessage(userSummaryPrice, cart, paymentMethod),
        Markup.keyboard(keyboards.initial)
          .resize()
          .extra(),
      )
    } catch (err) {
      console.error(err)
      await ctx.reply(
        papyrus.errorOnRequest,
        Markup.keyboard(keyboards.initial)
          .resize()
          .extra(),
      )
    }
  },
  invoiceFinal: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.checkout(userId)
    return await ctx.reply(
      papyrus.successfulOrder,
      Markup.keyboard(keyboards.initial)
        .resize()
        .extra(),
    )
  },
  getProductsByCategory: ctx => async (promoId: string) => {
    const goods = await ProductsModel.find({ linkedPromotion: promoId })
    const intermateArticlesQuery = []
    await goods.forEach(async (product: any) => {
      await intermateArticlesQuery.push({
        type: 'article',
        id: product._id,
        title: product.title,
        description: `${product.priceBefore} ${product.description}`,
        thumb_url: product.photoUrl,
        input_message_content: {
          message_text: `Продукт:${product.articule}:${product.linkedPromotion}`,
        },
        reply_markup: {},
      })
    })
    return await ctx.answerInlineQuery(intermateArticlesQuery, { cache_time: 0 })
  },
  createPromotion: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.update(userId, 'scope', 'onEnterPromotionName')
    return await ctx.reply(papyrus.enterPromotionName)
  },
  uploadClients: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.update(userId, 'scope', 'clientsUploading')
    return await ctx.reply(papyrus.uploadFile)
  },
  requestClientPhone: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    const ses = await session.receiveSession(userId)
    await session.update(userId, 'scope', 'clientPhone')
    return await ctx.reply(
      papyrus.requestClientPhone,
      Extra.markup(markup => markup.removeKeyboard()),
    )
  },
  clientPhoneReceived: ctx => async phoneNumber => {
    const {
      from: { first_name, id: userId },
    } = ctx
    const phoneValidated = validatePhone(phoneNumber)
    if (!phoneValidated) {
      return await ctx.reply(papyrus.wrongPhoneNumber)
    }
    const client: any = await ClientModel.findOne({ phoneNumber: phoneValidated })
    if (!client) {
      return await ctx.reply(
        papyrus.clientNotFound,
        Extra.markup(markup => markup.removeKeyboard()),
      )
    }
    await session.update(userId, 'scope', '')
    await session.update(userId, 'phone', phoneNumber)
    await session.update(userId, 'contragent', client.mainManager)

    await ctx.reply(
      papyrus.greeting(first_name),
      Markup.keyboard(keyboards.initial)
        .resize()
        .extra(),
    )
  },
  editProductQty: ctx => async rawProductArticule => {
    const {
      from: { id: userId },
    } = ctx
    const cart = await session.getEntity(userId, 'cart')
    const [prefix, articule] = rawProductArticule.split(':')
    const productObject = cart.find(product => product.articule === articule)
    return await ctx.editMessageReplyMarkup({
      inline_keyboard: inlineKeyboards.productEditKeyboard(productObject),
    })
  },
  operateQty: ctx => async rawProductData => {
    const [prefix, articule, qty] = rawProductData.split(':')
    if (qty < 1) {
      return false
    }
    return await ctx.editMessageReplyMarkup({
      inline_keyboard: inlineKeyboards.productEditKeyboard({ qty, articule }),
    })
  },
  acceptQty: ctx => async (rawProductData: string) => {
    const {
      from: { id: userId },
    } = ctx
    const cart = await session.getEntity(userId, 'cart')
    const [prefix, articule, qty] = rawProductData.split(':')
    const productObject = cart.find(product => product.articule === articule)
    const productIdx = cart.indexOf(productObject)
    cart[productIdx].qty = Number(qty)
    await session.update(userId, 'cart', cart)
    return await ctx.editMessageReplyMarkup({
      inline_keyboard: inlineKeyboards.inlineCart(cart),
    })
  },
  promotionNameReceived: ctx => async (promotionName: string) => {
    const {
      from: { id: userId },
    } = ctx
    if (!validatePromotionName(promotionName)) {
      return await ctx.reply(papyrus.wrongPromotionName)
    }
    await session.update(userId, 'scope', 'selectPromotionType')
    await session.update(userId, 'promotionName', promotionName)
    return await ctx.reply(
      papyrus.selectPromotionType,
      Markup.inlineKeyboard(inlineKeyboards.getPromotionTypes())
        .resize()
        .extra(),
    )
  },
  selectedPromotionType: ctx => async (promotionDataType: string) => {
    const [prefix, promotionType] = promotionDataType.split(':')
    const {
      from: { id: userId },
    } = ctx
    const promotionName = await session.getEntity(userId, 'promotionName')
    await session.update(userId, 'scope', 'goodsUploading')
    const newPromo = await PromotionsModel.create({
      nomination: promotionName,
      type: promotionType,
    })
    await session.update(userId, 'promotionId', newPromo._id)
    await clearInlineKeyboard(ctx)
    return await ctx.telegram.sendMessage(userId, papyrus.uploadFile)
  },
  deletePromotion: async ctx => {
    const promotions = await PromotionsModel.find({})
    return await ctx.reply(
      papyrus.selectPromotionToDelete,
      Markup.inlineKeyboard(inlineKeyboards.removePromotions(promotions))
        .resize()
        .extra(),
    )
  },
  selectedPromotionForDelete: ctx => async (promotionData: string) => {
    const [prefix, promoId] = promotionData.split(':')
    await PromotionsModel.findByIdAndDelete(promoId)
    await ProductsModel.deleteMany({ linkedPromotion: promoId })
    const residualPromotions = await PromotionsModel.find({})
    return await ctx.editMessageReplyMarkup({
      inline_keyboard: inlineKeyboards.removePromotions(residualPromotions),
    })
  },
  cancelOrder: async ctx => {
    const {
      from: { id: userId },
    } = ctx
    await session.checkout(userId)
    return await ctx.reply(
      papyrus.orderDiscarded,
      Markup.keyboard(keyboards.initial)
        .resize()
        .extra(),
    )
  },
}

const anthology = new Map()
for (const scenario in availableScenarious) {
  if (Reflect.has(availableScenarious, scenario)) {
    anthology.set(scenario, scenarious[scenario])
  }
}

export { anthology }
