import { session } from '../Session'

export default class ShoppingCart {
  constructor() { }

  public async addProduct(product, userId: any) {
    const userCart = await session.getEntity(userId, 'cart')
    userCart.push(product)
    await session.update(userId, 'cart', userCart)
  }

  public async removeProduct(articules: string[], userId: any) {
    let userCart = await session.getEntity(userId, 'cart')
    const updatedCart = userCart.filter(product => {
      return articules.indexOf(product.articule) < 0
    })
    await session.update(userId, 'cart', updatedCart)
  }

  public getTotalAmount(cart): number {
    let totalAmount = 0
    cart.forEach(product => {
      totalAmount += Number(product.itemPrice)
    })
    return Math.round(totalAmount)
  }
}