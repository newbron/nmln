export enum EDeliveryTypes {
  'NovaPoshta' = 0,
  'Justin' = 1,
  'APCourier' = 2
}

export const discountTypes = ['3+2', '5+5', 'alta moda']

export type TUserId = string | number

export interface ICartProduct {
  title: string,
  priceBefore: number,
  priceAfter: number,
  qty: number,
  articule: string,
  discountType: string,
  itemPrice: number
}

export * from './models'