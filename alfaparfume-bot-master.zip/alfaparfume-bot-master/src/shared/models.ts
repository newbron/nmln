import { Document } from 'mongoose'

export interface IPromotion extends Document {
  nomination: string
  type: string
}

export interface IProduct extends Document {
  articule: string,
  title: string,
  description: string,
  startSale: string,
  endSale: string,
  priceBefore: number,
  priceAfter: number,
  photoUrl: string,
  linkedPromotion: string
}