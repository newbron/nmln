import fs from 'fs'
import path from 'path'
import Axios from 'axios'
import Markup from 'telegraf/markup'
import dotenv from 'dotenv'

import keyboards from '../services/Keyboards/keyboard'
import { ICartProduct } from '../shared'
import { session } from '../services/Session'
import papyrus from '../stubs/papyrus'
import { uploadGoods, returnContragentsFromExcel } from '../services/Excel'

dotenv.config()
const BOT_TOKEN = process.env.BOT_TOKEN

export const isJson = (toParse: string) => {
  return !!JSON.parse(toParse)
}

export const validatePhone = (phone: string): boolean | string => {
  let phoneValidated = phone.replace(/\D/g, '')
  // phone length should be equal 12 but min 10
  if (!phoneValidated || phoneValidated.length < 10 || phoneValidated.length > 12) {
    return false
  }
  if (phoneValidated.length === 10) phoneValidated = `38${phoneValidated}`
  if (phoneValidated.length === 11) phoneValidated = `3${phoneValidated}`
  return phoneValidated
}

export const paginator = (arr, perPage) => {
  if (perPage < 1 || !arr) {
    return () => []
  }

  return function(page) {
    const basePage = page * perPage

    return page < 0 || basePage >= arr.length ? [] : arr.slice(basePage, basePage + perPage)
  }
}

export const apChatSummaryMessage = (name, phone, address, cart: ICartProduct[], summaryPrice) => {
  let summaryString = `Користувач зробив замовлення!
Ім'я: ${name}
Номер телефона: ${phone}
Адрес: ${address}
Загальна вартість: ${Math.round(summaryPrice)}грн

Кошик:`
  cart.forEach(product => {
    const price = Math.round(product.priceBefore)
    summaryString += `\n${product.title} (${price}грн)`
  })
  return summaryString
}

export const userSummaryMessage = (summaryPrice, cart: ICartProduct[], paymentMethod) => {
  let summaryString = `✅Замовлення прийнято!.

Загальна вартість: ${summaryPrice}грн
Кошик:`
  cart.forEach(product => {
    summaryString += `\n${product.title} (${product.priceBefore}грн, ${product.articule}), ${product.qty} шт. - ${product.itemPrice}грн`
  })
  if (paymentMethod === 'Безготівковий') {
    summaryString += papyrus.cashlessPayment
  }
  return summaryString
}

export const validateAddress = (address: string) => {
  return address.length < 8 ? false : true
}

export const getResultDiscount = (availableDiscounts: string, discount: string) => {
  if (availableDiscounts.length === 0) {
    return discount
  }
  if (availableDiscounts.match(discount)) {
    return availableDiscounts
  }
  const resultDiscount = `${availableDiscounts}; ${discount}`
  return resultDiscount
}

export const onDocumentReceived = async (ctx: any, scope: string, userId: number) => {
  try {
    const userDocument = ctx.message.document
    const sourcePath = await ctx.telegram.getFileLink(userDocument.file_id)
    const splitedUrl = sourcePath.split('/')
    const filePath = path.resolve(__dirname, '../..', 'data', splitedUrl[splitedUrl.length - 1])
    await uploadFile(sourcePath, filePath)

    if (scope === 'goodsUploading') {
      const promoId = await session.getEntity(userId, 'promotionId')
      await ctx.reply(papyrus.uploadStarting)
      await uploadGoods(filePath, promoId)
      await session.update(userId, 'promotionName', '')
      await session.update(userId, 'promotionId', '')
    }
    if (scope === 'clientsUploading') {
      await ctx.reply(papyrus.uploadStarting)
      await returnContragentsFromExcel(filePath)
    }

    await session.update(userId, 'scope', '')
    await session.update(userId, 'promotionName', '')
    return await ctx.reply(
      papyrus.uploadEnded,
      Markup.keyboard(keyboards.initial)
        .resize()
        .extra(),
    )
  } catch (err) {
    return await ctx.reply(papyrus.errorOnFileUploading)
  }
}

export const uploadFile = async (source: string, filePath: string) => {
  const resp = await Axios({ url: source, method: 'GET', responseType: 'stream' })
  resp.data.pipe(fs.createWriteStream(filePath))
  return new Promise((resolve, reject) => {
    resp.data.on('end', () => resolve())
    resp.data.on('error', err => reject(err))
  })
}

export const validatePromotionName = (promotionName: string) => {
  return promotionName.length < 3 ? false : true
}

export const getFileUrl = async (fileId: string) => {
  const fileDataResult = await Axios.get(`https://api.telegram.org/bot${BOT_TOKEN}/getFile`, {
    params: { file_id: fileId },
  })
  const filePath = fileDataResult.data.result.file_path
  if (!filePath) return false

  const barcodeFilePath = `https://api.telegram.org/file/bot${BOT_TOKEN}/${filePath}`
  // TODO find an barcode api reader to pass the url to get the value of the barcode.
}

// const receiveUrl = async (filePath: string) => {
//   return await Axios.get(`https://api.telegram.org/file/bot${BOT_TOKEN}/${filePath}`)
// }
